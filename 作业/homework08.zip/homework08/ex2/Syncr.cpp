
#include <windows.h>
#include <iostream>
#include "syncr.h"

using namespace std;

HANDLE _hThread[3];
DWORD  ThreadID[3];
DWORD  ThreadArg[3] = {0, 0, 0};

int main()
{
	_hThread[0] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadProcA, &ThreadArg[0], CREATE_SUSPENDED, &ThreadID[0]);
	_hThread[1] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadProcB, &ThreadArg[1], CREATE_SUSPENDED, &ThreadID[1]);
	_hThread[2] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadProcC, &ThreadArg[2], CREATE_SUSPENDED, &ThreadID[2]);

	SetThreadPriority(_hThread[0], THREAD_PRIORITY_ABOVE_NORMAL);

	ResumeThread(_hThread[0]);
	ResumeThread(_hThread[1]);
	ResumeThread(_hThread[2]);

	Sleep(1000);

	CloseHandle(_hThread[0]);
	CloseHandle(_hThread[1]);
	CloseHandle(_hThread[2]);

	return 0;
}

UINT ThreadProcA(LPVOID pParam)
{
	for (int i = 0; i < 10; i++)
	{
		cout<<'A';
	}
	return 0;
}

UINT ThreadProcB(LPVOID pParam)
{
	for (int i = 0; i < 10; i++)
	{
		cout<<'B';
	}
	return 0;
}

UINT ThreadProcC(LPVOID pParam)
{
	for (int i = 0; i < 10; i++)
	{
		cout<<'C';
	}
	return 0;
}
