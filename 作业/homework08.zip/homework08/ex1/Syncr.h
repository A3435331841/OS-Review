int main();
UINT ThreadProc0(LPVOID pParam);
UINT ThreadProc1(LPVOID pParam);
