using namespace std;

extern int gv;

int func();
