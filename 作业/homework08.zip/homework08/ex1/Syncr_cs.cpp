
#include <windows.h>
#include <iostream>
#include "syncr.h"

using namespace std;

HANDLE _hThread[2];
DWORD  ThreadID[2];
DWORD  ThreadArg[2] = {0, 0};

CRITICAL_SECTION g_cs;

char g_cArray[11];

int main()
{
	InitializeCriticalSection(&g_cs);
	_hThread[0] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadProc0, &ThreadArg[0], CREATE_SUSPENDED, &ThreadID[0]);
	_hThread[1] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadProc1, &ThreadArg[1], CREATE_SUSPENDED, &ThreadID[1]);

	ResumeThread(_hThread[0]);
	ResumeThread(_hThread[1]);

	Sleep(1000);
	g_cArray[10] = '\0';
	cout<<g_cArray;

	CloseHandle(_hThread[0]);
	CloseHandle(_hThread[1]);

	return 0;
}

UINT ThreadProc0(LPVOID pParam)
{
	//�����ٽ���
	EnterCriticalSection(&g_cs);
	//�Թ�����Դ����д�����
	for (int i = 0; i < 10; i++)
	{
		g_cArray[i] = 'a';
		Sleep(1);
	}
	//�뿪�ٽ���
	LeaveCriticalSection(&g_cs);
	return 0;
}

UINT ThreadProc1(LPVOID pParam)
{
	//�����ٽ���
	EnterCriticalSection(&g_cs);
	//�Թ�����Դ����д�����
	for (int i = 0; i < 10; i++)
	{
		g_cArray[10 - i - 1] = 'b';
		Sleep(1);
	}
	//�뿪�ٽ���
	LeaveCriticalSection(&g_cs);
	return 0;
}
