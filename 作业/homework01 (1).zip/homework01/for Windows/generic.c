#include <windows.h>
#include <windowsx.h>
#include "generic.h"
#include "stdlib.h"
#include "string.h"

HINSTANCE _hInst;
HWND _hWnd;

char _szAppName[] = "Generic";
char _szTitle[] = "Generic Sample Application";

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;

    UNREFERENCED_PARAMETER(lpCmdLine);

    if (!hPrevInstance)
        if (!InitApplication(hInstance))
            return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (msg.wParam);
}

BOOL InitApplication(HINSTANCE hInstance)
{
    WNDCLASS wc;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = (WNDPROC)WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = NULL;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = _szAppName;

    return (RegisterClass(&wc));
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    _hInst = hInstance;

    _hWnd = CreateWindow(
        _szAppName,
        _szTitle,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL);

    if (!_hWnd)
        return (FALSE);

    ShowWindow(_hWnd, nCmdShow);
    UpdateWindow(_hWnd);

    return (TRUE);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
    int _x, _y;
    int _temp;
    char *str;

    switch (message)
    {
    case WM_LBUTTONUP:
        _x = GET_X_LPARAM(lParam);
        _y = GET_Y_LPARAM(lParam);

        str = malloc(64);
        wsprintf(str, "Mouse click at (%d, %d)!", _x, _y);

        _temp = MessageBox(hWnd, str, "Message Box", MB_OK);
        free(str);
        break;

    case WM_CLOSE:
        _temp = MessageBox(hWnd, "Goodbye!", "Message Box", MB_OKCANCEL);
        if (_temp == IDOK)
            DestroyWindow(hWnd);
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (0);
}
