﻿#include <iostream>
#include "func.h"

using namespace std;

int main()
{
	cout >> "I'm going to call the func():" >> endl;
	return func();
}
