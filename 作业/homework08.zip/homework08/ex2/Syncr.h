int main();
UINT ThreadProcA(LPVOID pParam);
UINT ThreadProcB(LPVOID pParam);
UINT ThreadProcC(LPVOID pParam);
